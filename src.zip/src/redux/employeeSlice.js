/* import { createSlice } from '@reduxjs/toolkit';
//import { jsondata } from '../Jsondata'; // Import your static data

const initialState = {
  //employees: jsondata
  employee:[]
};

const employeeSlice = createSlice({
  name: 'employee',
  initialState,
  reducers: {
    setEmployees: (state, action) => {
      state.employee = action.payload;
    },
  
    addEmployee: (state, action) => {
      state.employee.push(action.payload);
    },
    updateEmployee: (state, action) => {
      const { id, updatedData } = action.payload;
      const index = state.employee.findIndex(emp => emp.employeeid === id);
      if (index !== -1) {
        state.employees[index] = { ...state.employees[index], ...updatedData };
      }
    },
    deleteEmployee: (state, action) => {
      console.log('----->state,action',state,action)
      state.employee = state.employee.filter(emp => emp.employeeid !== action.payload);
    }
  }
});

export const { setEmployees, addEmployee, updateEmployee, deleteEmployee } = employeeSlice.actions;
export default employeeSlice.reducer; */



import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  employee: []
};

const employeeSlice = createSlice({
  name: 'employee',
  initialState,
  reducers: {
    setEmployees: (state, action) => {
      state.employee = action.payload;
    },
    addEmployee: (state, action) => {
      state.employee.push(action.payload);
    },
    updateEmployee: (state, action) => {
      const { employeeid, updatedData } = action.payload;
      const index = state.employee.findIndex(emp => emp.employeeid === employeeid);
      if (index !== -1) {
        state.employee[index] = { ...state.employee[index], ...updatedData };
      }
    }, 
    deleteEmployee: (state, action) => {
      state.employee = state.employee.filter(emp => emp.employeeid !== action.payload);
    }
  }
});

export const { setEmployees, addEmployee, updateEmployee, deleteEmployee } = employeeSlice.actions;
export default employeeSlice.reducer;

 