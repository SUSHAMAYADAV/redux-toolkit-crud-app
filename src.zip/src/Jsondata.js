export const jsondata = [
    {
      "employeeid": "00001",
      "name": "Alice Johnson",
      "department": "Engineering",
      "salary": 85000,
      "description": "Senior Engineer with a focus on system architecture."
    },
    {
      "employeeid": "00002",
      "name": "Bob Smith",
      "department": "Marketing",
      "salary": 72000,
      "description": "Marketing Specialist with expertise in digital campaigns."
    },
    {
      "employeeid": "00003",
      "name": "Carol Davis",
      "department": "Finance",
      "salary": 95000,
      "description": "Finance Manager responsible for budgeting and forecasting."
    },
    {
      "employeeid": "00004",
      "name": "David Lee",
      "department": "Human Resources",
      "salary": 65000,
      "description": "HR Coordinator handling recruitment and employee relations."
    },
    {
      "employeeid": "00005",
      "name": "Eva Brown",
      "department": "Engineering",
      "salary": 87000,
      "description": "Lead Engineer with extensive experience in software development."
    },
    {
      "employeeid": "00006",
      "name": "Frank Wilson",
      "department": "Sales",
      "salary": 70000,
      "description": "Sales Representative with a strong track record in client acquisition."
    },
    {
      "employeeid": "00007",
      "name": "Grace Martinez",
      "department": "IT",
      "salary": 78000,
      "description": "IT Specialist focusing on network security and system maintenance."
    },
    {
      "employeeid": "00008",
      "name": "Hank Thompson",
      "department": "Marketing",
      "salary": 71000,
      "description": "Marketing Analyst skilled in market research and strategy development."
    },
    {
      "employeeid": "00009",
      "name": "Ivy Garcia",
      "department": "Finance",
      "salary": 92000,
      "description": "Senior Financial Analyst with a background in investment analysis."
    },
    {
      "employeeid": "00010",
      "name": "Jack Anderson",
      "department": "Sales",
      "salary": 68000,
      "description": "Sales Associate with experience in customer relationship management."
    }
  ];
  
  